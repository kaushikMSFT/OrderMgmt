﻿using Amazon;
using Amazon.SQS;
using Amazon.SQS.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace OrderProcessingOrchestrator.Providers
{
    public class QueueDataProvider
    {
        // Create the Amazon SQS client
        AmazonSQSClient amazonSQSClient=null;
        private const string QueueEndpointUri =
            "https://sqs.us-east-2.amazonaws.com/360174799684/OrderProcessingQueue";
        private const int maxMessages = 10;
        private const int waitTime = 10;

        //private readonly HttpClient _httpClient;

        public QueueDataProvider()
        {
            // _httpClient = new HttpClient();
            // Create the Amazon SQS client
            amazonSQSClient = new AmazonSQSClient(RegionEndpoint.USEast2);
        }

        public async Task<ReceiveMessageResponse> GetMessages(CancellationToken cancellationToken)
        {
            try
            {
                // var response = await _httpClient.GetAsync(RandomStringUri, cancellationToken);

                //  if (response.IsSuccessStatusCode)
                //  {
                //   RandomString = await response.Content.ReadAsStringAsync();
                // }
                return await amazonSQSClient.ReceiveMessageAsync(new ReceiveMessageRequest
                {
                    QueueUrl = QueueEndpointUri,
                    MaxNumberOfMessages = maxMessages,
                    WaitTimeSeconds = waitTime,
                    
                    // (Could also request attributes, set visibility timeout, etc.)
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return null;
            }
        }

        public async Task<bool> DeleteMessage(CancellationToken cancellationToken, List<Message> messages)
        {
            try
            {
                if (messages?.Count == 0)
                    return true;
                DeleteMessageRequest mreq = new DeleteMessageRequest();
                DeleteMessageBatchRequest req = new DeleteMessageBatchRequest();
                mreq.QueueUrl = QueueEndpointUri;
                req.QueueUrl = QueueEndpointUri;
                messages.ForEach(message => req.Entries.Add(new DeleteMessageBatchRequestEntry() { Id = message.MessageId, ReceiptHandle = message.ReceiptHandle }));
                //req.Entries.Add(new DeleteMessageBatchRequestEntry() { Id = "123", ReceiptHandle = "" });
                DeleteMessageBatchResponse deleteMessageBatchResponse = await amazonSQSClient.DeleteMessageBatchAsync(req);
                if (deleteMessageBatchResponse.Failed.Count > 0)
                    return false;
                else
                    return true;
            }
            catch(Exception  ex)
            {
                Console.Write(ex.Message);
                return false;
            }
            //await amazonSQSClient.DeleteMessageAsync(mreq);
        }
        //public string RandomString { get; private set; } = string.Empty;
    }
}

